from distutils.core import setup

setup(
        name="mzExplorer",
        version="0.1",
        url="http://github.com/uweschmitt/msExpert",
        author="uwe schmitt",
        author_email="uschmitt@mineway.de",
        packages=["mzExplorer"]
     )
