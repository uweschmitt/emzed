__builtins__["MMU"] = 0.001

__builtins__["SECONDS"] = 1.0
__builtins__["MINUTES"] = 60.0
__builtins__["HOURS"] = 60.0 * MINUTES

