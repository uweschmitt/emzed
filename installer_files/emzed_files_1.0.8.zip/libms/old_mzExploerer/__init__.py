from mzExplorer import inspectMap, MzExplorer
