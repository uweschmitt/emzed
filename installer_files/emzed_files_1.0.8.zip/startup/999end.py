print
print "*"*60
print "STARTUP FILES LOADED"
print "*"*60
print
