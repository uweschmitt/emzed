print
print "*"*60
print "LOAD STARTUP FILES"
print "*"*60
print
