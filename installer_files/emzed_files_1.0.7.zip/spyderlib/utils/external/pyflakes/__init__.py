
__version__ = '0.4-ast' # Development version of pyflakes based on ast
