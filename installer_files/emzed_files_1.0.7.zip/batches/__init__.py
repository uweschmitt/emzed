from feature_detector import *
from peak_picker import *

# remove clutter
try:
    del feature_detector
except: 
    pass
try:
    del peak_picker
except: 
    pass
