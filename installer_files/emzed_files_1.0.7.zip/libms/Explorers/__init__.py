from mzExplorer import inspectPeakMap, MzExplorer
from TableExplorer import inspect, TableExplorer
