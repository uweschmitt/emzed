R_LIBS=libs; /e/Programme/R/R-2.13.1/bin/i386/R.exe --vanilla
